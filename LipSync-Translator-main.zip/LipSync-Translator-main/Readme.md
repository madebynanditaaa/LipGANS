# 🎙️ LipSync Translator  
### *AI-Based English-to-Hindi Video Translation with Realistic Lip Synchronization*  

> **By:** Meet Golani, Abhishek Sah, Vaishnawi Kalgaonkar, Nandita Singh  
> **Under the guidance of:** Dr. Shwetambari Chiwhane  
> Department of Computer Science & Engineering, Symbiosis Institute of Technology, Pune  

---

## 🧠 Overview

**LipSync Translator** is an AI-powered system that converts **English text into realistic lip-movement video sequences** — without relying on any audio input.  
Unlike traditional systems such as *Wav2Lip* or *LipGAN*, which depend on clean speech signals, this model performs **text-driven lip animation** using a **multi-GAN architecture**, trained on phoneme–viseme mappings.

It aims to make dubbing, silent communication, and assistive speech applications more accessible through **audio-free speech synthesis**.

---

## 🧩 Problem Statement

Existing lip-synchronization models depend heavily on high-quality audio.  
However, in many real-world cases — such as damaged audio, multilingual dubbing, or silent communication for the hearing-impaired — audio may be missing or unusable.  

Our system bridges this gap by directly translating **text → phonemes → visemes → lip-motion video**, enabling natural lip articulation even in the absence of sound.

---

## 🎯 Objectives

- Develop a **text-to-viseme pipeline** using phoneme-based conditioning.  
- Design **independent 3D Conditional GANs (cGANs)** for each viseme class to prevent mode collapse.  
- Implement **automatic mouth-region extraction** using MediaPipe FaceMesh.  
- Create a **modular inference system** that concatenates generated clips into smooth lip animations.  
- Evaluate model quality using metrics like **SSIM**, **FID**, and **LPIPS**.  

---

## 🧱 System Architecture

### 🔹 Pipeline

1. **Text → Phoneme Conversion** using CMU Pronouncing Dictionary  
2. **Phoneme → Viseme Mapping** (10 viseme classes)  
3. **Viseme-Specific 3D Conditional GANs** for frame generation  
4. **Clip Concatenation & Temporal Smoothing** for continuous motion  
5. **Final Rendering** into a realistic lip-motion video  

### 🔹 GAN Design
- **Generator:** 3D Conv-Transpose layers produce 3-frame mouth clips.  
- **Discriminator:** Classifies real vs generated viseme clips using 3D convolutions.  
- **Loss:** Binary Cross Entropy + Adversarial Loss.  

---

## 🧮 Dataset

**TCD-TIMIT Audio-Visual Corpus**

| Attribute | Description |
|------------|-------------|
| Speakers | 62 (32M / 30F) |
| Sentences | 6,913 phonetically rich English sentences |
| Frame rate | 10 FPS |
| Resolution | High-quality frontal & 30° view |
| Sampling rate | 16 kHz audio (for alignment only) |

Preprocessing steps:
- Phoneme segmentation using **Master Label Files (.mlf)**
- **MediaPipe FaceMesh** for mouth ROI extraction  
- **64×64 spatial normalization**, 3-frame temporal grouping  
- Sorting into **10 viseme folders**

---

## ⚙️ Tech Stack

| Category | Tools / Libraries |
|-----------|------------------|
| Environment | Google Colab, Jupyter Notebook, VS Code |
| Language | Python 3.10 |
| Deep Learning | TensorFlow / Keras |
| Preprocessing | OpenCV, MediaPipe, ffmpeg, ImageIO |
| Data Handling | NumPy, NLTK (CMUdict) |
| Visualization | Matplotlib |

---

## 📊 Results

| Metric | Description | Observation |
|---------|--------------|--------------|
| **Inference Speed** | < 1 second per viseme clip (RTX 3090 GPU) | Fast real-time generation |
| **Output Resolution** | 64 × 64 pixels (3 frames per viseme) | Compact, efficient |
| **SSIM (↑)** | Structural Similarity | High visual similarity |
| **FVD (↓)** | Frechet Video Distance | Low temporal distortion |
| **LPIPS (↓)** | Perceptual Similarity Loss | High perceptual realism |

**Observation:**  
Produces clear articulation patterns — closed lips, rounded lips, fricatives — with realistic temporal flow and coherence across viseme boundaries.

---

## 🚀 Applications

- 🎬 **Text-to-Video Dubbing** — silent or multilingual dubbing without recorded audio.  
- 🧏 **Assistive Communication** — enhances accessibility for hearing-impaired users.  
- 🗣️ **Language Learning** — visual pronunciation feedback for speech training.  
- 🤖 **Virtual Avatars & Conversational Agents** — text-based realistic avatars.  
- 🧩 **Speechless Video Generation** — privacy-preserving media synthesis.  

---

## 🔮 Future Scope

- Extend to **full-face animation** with emotion and expression conditioning.  
- Integrate with **Text-to-Speech (TTS)** for complete talking-face generation.  
- Optimize using **ConvLSTM** or **Temporal GAN** for smoother transitions.  
- Add **multilingual support** for Indian and global languages.  
- Develop **lightweight mobile/web-compatible versions** for deployment.  

---

## 🧾 Citation

If you use this repository in your research or project:

```text
@project{lipsync_translator_2025,
  title={LipSync Translator: AI-Based English-to-Hindi Video Translation with Realistic Lip Synchronization},
  author={Meet Golani and Abhishek Sah and Vaishnawi Kalgaonkar and Nandita Singh},
  year={2025},
  institution={Symbiosis Institute of Technology, Pune}
}
