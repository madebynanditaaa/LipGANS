# === XTTS Voice Cloning (Hindi) ===
import os, subprocess, torch, librosa, numpy as np, soundfile as sf
from TTS.api import TTS

WORK = "/kaggle/working/work"
DATASET = "meetgoll"
INPUT_VIDEO = f"/kaggle/input/{DATASET}/meet.mp4"
HI_SRT = os.path.join(WORK, "meet_hi.srt")
OUT_WAV = os.path.join(WORK, "hindi_tts_16k.wav")

# Extract speaker reference
VOICE_REF = os.path.join(WORK, "meet_16k_mono.wav")
subprocess.run(["ffmpeg","-y","-i", INPUT_VIDEO, "-vn","-ac","1","-ar","16000","-acodec","pcm_s16le", VOICE_REF], check=True)

# Read text from Hindi SRT
def read_srt_text(path):
    lines, buf = [], []
    with open(path,"r",encoding="utf-8") as f:
        for line in f:
            if line.strip(): buf.append(line.strip())
            else:
                if len(buf)>=3: lines.append(" ".join(buf[2:])); buf=[]
    return " ".join(lines)

text_hi = read_srt_text(HI_SRT)
device = "cuda" if torch.cuda.is_available() else "cpu"
tts = TTS(model_name="tts_models/multilingual/multi-dataset/xtts_v2").to(device)
wav = tts.tts(text=text_hi, speaker_wav=VOICE_REF, language="hi")
wav = wav.detach().cpu().numpy() if hasattr(wav,"detach") else np.asarray(wav)

# Normalize and save
wav = librosa.resample(wav, orig_sr=22050, target_sr=16000)
sf.write(OUT_WAV, wav, 16000, subtype="PCM_16")
print("✅ Generated Hindi TTS:", OUT_WAV)
