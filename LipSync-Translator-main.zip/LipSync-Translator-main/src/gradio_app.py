# === Gradio Frontend ===
import gradio as gr
from asr_translate import write_srt
from tts_generation import TTS
from lipsync_infer import subprocess, W2L

def run_pipeline(video):
    # Your full process sequence
    # (ASR → Translate → TTS → LipSync)
    # Call scripts in order for demo
    subprocess.run(["python","src/asr_translate.py"], check=True)
    subprocess.run(["python","src/tts_generation.py"], check=True)
    subprocess.run(["python","src/lipsync_infer.py"], check=True)
    return "/kaggle/working/work/output_hindi_lipsync.mp4"

demo = gr.Interface(
    fn=run_pipeline,
    inputs=gr.Video(label="Upload English Video"),
    outputs=gr.Video(label="Lip-Synced Hindi Output"),
    title="LipSync Translator (Whisper + NLLB + XTTS + Wav2Lip)"
)

demo.launch(share=True)
