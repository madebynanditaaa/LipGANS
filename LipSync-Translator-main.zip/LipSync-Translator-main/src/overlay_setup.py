# === OVERLAY SETUP ===
import os, sys, subprocess, textwrap
from pathlib import Path

PKGS = "/kaggle/working/pkgs"
os.makedirs(PKGS, exist_ok=True)

def sh(cmd):
    print(">>>", cmd)
    subprocess.run(cmd, shell=True, check=True)

# 1) Base installs
sh("apt -y install -qq ffmpeg")
sh("pip -q install torch==2.3.1 torchvision==0.18.1 torchaudio==2.3.1 --index-url https://download.pytorch.org/whl/cu121")

# 2) Overlay packages
WHEELS = [
    "numpy==1.26.4","huggingface-hub==0.34.1","tokenizers==0.19.1","transformers==4.44.2",
    "sentencepiece==0.1.99","openai-whisper==20231117","TTS==0.21.3",
    "librosa==0.10.2.post1","pydub==0.25.1","soundfile==0.12.1",
    "tqdm==4.66.4","opencv-python==4.8.1.78"
]
for w in WHEELS:
    sh(f'pip -q install --no-cache-dir --no-deps -t "{PKGS}" {w}')

# 3) Wav2Lip repo
if not Path("/kaggle/working/Wav2Lip").exists():
    sh("cd /kaggle/working && git clone https://github.com/Rudrabha/Wav2Lip.git")
os.makedirs("/kaggle/working/Wav2Lip/checkpoints", exist_ok=True)
sh("wget -q -O /kaggle/working/Wav2Lip/checkpoints/wav2lip.pth https://github.com/justinjohn0306/Wav2Lip/releases/download/models/wav2lip.pth")
sh("wget -q -O /kaggle/working/Wav2Lip/checkpoints/wav2lip_gan.pth https://github.com/justinjohn0306/Wav2Lip/releases/download/models/wav2lip_gan.pth")

if PKGS not in sys.path:
    sys.path.insert(0, PKGS)

import torch, transformers, whisper
print("Torch:", torch.__version__, "| CUDA:", torch.cuda.is_available())
print("transformers:", transformers.__version__)
print("whisper:", whisper.__version__)
print("✅ Overlay ready — imports OK.")
