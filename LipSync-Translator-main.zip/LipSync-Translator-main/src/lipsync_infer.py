# === Wav2Lip Inference ===
import os, sys, subprocess

W2L = "/kaggle/working/Wav2Lip"
WORK = "/kaggle/working/work"
OUT = f"{WORK}/output_hindi_lipsync.mp4"

env = os.environ.copy()
env["NUMBA_DISABLE_JIT"] = "1"
env["LIBROSA_NUMBA"] = "0"
env["NUMBA_CACHE_DIR"] = "/kaggle/working/numba_cache"
env["PYTHONPATH"] = W2L

cmd = [
    sys.executable, "inference.py",
    "--checkpoint_path", "checkpoints/wav2lip_gan.pth",
    "--face", "/kaggle/input/meetgoll/meet.mp4",
    "--audio", f"{WORK}/hindi_tts_16k.wav",
    "--outfile", OUT,
    "--pads", "0","10","0","0",
    "--resize_factor", "1",
    "--wav2lip_batch_size", "8",
    "--face_det_batch_size", "2",
]
print(">>> Running Wav2Lip inference...")
rc = subprocess.run(cmd, cwd=W2L, env=env).returncode
if rc != 0:
    print("GAN failed, retrying with base checkpoint.")
    cmd[3] = "checkpoints/wav2lip.pth"
    subprocess.run(cmd, cwd=W2L, env=env, check=True)
print("✅ Output:", OUT)
