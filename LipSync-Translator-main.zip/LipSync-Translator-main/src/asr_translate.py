# === ASR + Translation (Whisper + NLLB) ===
import os, subprocess, torch, glob
import whisper
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

DATASET = "meetgoll"
input_video = f"/kaggle/input/{DATASET}/meet.mp4"
assert os.path.exists(input_video), f"Video not found: {input_video}"
print("Using video:", input_video)

workdir = "/kaggle/working/work"
os.makedirs(workdir, exist_ok=True)
base = os.path.splitext(os.path.basename(input_video))[0]
wav_path = os.path.join(workdir, f"{base}_16k_mono.wav")
en_srt  = os.path.join(workdir, f"{base}_en.srt")
hi_srt  = os.path.join(workdir, f"{base}_hi.srt")

# 1) Extract audio
subprocess.run(["ffmpeg","-y","-i", input_video,"-vn","-ac","1","-ar","16000","-acodec","pcm_s16le", wav_path], check=True)

# 2) Whisper ASR
device = "cuda" if torch.cuda.is_available() else "cpu"
model = whisper.load_model("medium", device=device)
result = model.transcribe(wav_path, language="en", verbose=False)
segments = result["segments"]

# 3) Save English subtitles
def srt_time(t):
    h, m = divmod(int(t // 60), 60)
    s, ms = divmod(int((t % 60) * 1000), 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def write_srt(segs, path, key):
    with open(path,"w",encoding="utf-8") as f:
        for i,s in enumerate(segs,1):
            f.write(f"{i}\n{srt_time(s['start'])} --> {srt_time(s['end'])}\n{s[key]}\n\n")

write_srt(segments, en_srt, "text")

# 4) Translate English → Hindi using NLLB
MODEL_ID = "facebook/nllb-200-distilled-600M"
SRC, TGT = "eng_Latn", "hin_Deva"
tok = AutoTokenizer.from_pretrained(MODEL_ID)
mt  = AutoModelForSeq2SeqLM.from_pretrained(MODEL_ID).to(device)

texts = [s["text"].strip() for s in segments]
enc = tok(texts, return_tensors="pt", padding=True, truncation=True).to(device)
gen = mt.generate(**enc, forced_bos_token_id=tok.convert_tokens_to_ids(TGT))
out = tok.batch_decode(gen, skip_special_tokens=True)
for s, hi in zip(segments, out): s["text_hi"] = hi
write_srt([{"start": s["start"], "end": s["end"], "text": s["text_hi"]} for s in segments], hi_srt, "text")
print("✅ Translated Hindi SRT:", hi_srt)
